# Template Fill Patterns: Detection & Procedure

Decides, for an uploaded template, whether to **strict-fill** (edit the existing file's XML, touching only placeholder content) or **style-match** (read its style and regenerate a new file). Run this decision once per uploaded template, before writing anything.

## Step 1: Inspect

```bash
extract-text template.docx                          # markdown text view — scan for placeholder tokens
python scripts/office/unpack.py template.docx unpacked/   # raw XML — scan for content controls
```
(Script paths relative to the `docx` skill's directory — see that skill's SKILL.md header note.)

## Step 2: Detection heuristics — any of these present = strict-fill

- Bracketed instruction tokens: `[Insert ...]`, `[Enter ...]`, `[TBD]`, `<Insert Title Here>`.
- Double-brace or double-angle merge tokens: `{{field_name}}`, `<<FieldName>>`.
- Word content-control placeholder text in the unpacked XML — look for `<w:sdt>` blocks containing `<w:showingPlcHdr/>` or literal placeholder text `Click or tap here to enter text.` / `Choose an item.`.
- A heading immediately followed by another heading (no body text between them) where the template otherwise has body text after every other heading — signals "this section is waiting to be filled," not "this section is intentionally short."
- An underscore run used as a fill-in line: `Author: ________________`.
- A table where header row is populated but data rows are empty or contain only placeholder text like "TBD" / "—".

**None of the above, but the document has a clear heading hierarchy and visible styling (fonts, colors, header/footer, logo)** → style-match. This is typically either a blank structural shell with just headings, or a previously-completed example FDD handed over as "make it look like this one."

**Ambiguous (some placeholders, but also large pre-written boilerplate sections)** → strict-fill for the placeholder slots, leave the boilerplate untouched. Don't regenerate sections that already have real content just because other sections in the same file have placeholders.

## Step 3a: Strict-fill procedure

Follow the `docx` skill's "Editing Existing Documents" workflow exactly:
1. `unpack.py` (already done in Step 1 above, reuse the same `unpacked/` dir).
2. Edit `unpacked/word/document.xml` with the `str_replace`/Edit tool directly — never a Python script for this part, per the `docx` skill's own guidance. Replace only the placeholder run's text content; preserve the surrounding `<w:rPr>` (font, size, bold) exactly so the inserted content visually matches its slot.
   - For `<w:sdt>` content-control placeholders: replace the placeholder text inside `<w:sdtContent>`, leave the `<w:sdtPr>` wrapper alone unless it actively breaks rendering.
   - For underscore fill-in lines: replace the underscores with the value, don't leave a dangling trailing underscore run.
   - For empty table data rows: fill cells directly; if the template's row count doesn't match the data count (e.g. 3 blank rows but 5 sign-off names gathered), add rows matching the existing row's `<w:tr>`/`<w:tc>` structure rather than guessing a different layout.
3. `pack.py` with `--original template.docx` to validate and produce the final file.

Never touch headers, footers, the logo image relationship, or any already-populated body paragraph — strict-fill means *only* the detected placeholder slots change.

## Step 3b: Style-match procedure

1. From the unpacked XML, note: heading style IDs and their `run`/`paragraph` properties (font, size, color, spacing, `outlineLevel`), any numbering scheme, header/footer content, and whether a logo image is present (note its relationship but do **not** reuse the client's actual logo file in the new document unless the user explicitly says to keep their letterhead — by default, regenerate as plain text matching their *style*, not their literal branding asset).
2. Map the template's existing heading list against `references/default-fdd-structure.md`. For each of the client's headings, place the corresponding gathered content under it. For any standard FDD topic with no matching heading in the client's template, add it using the default structure's wording and the same heading style just extracted — don't invent a new visual style for the added sections.
3. Generate via the `docx` skill's "Creating New Documents" (docx-js) workflow, applying the extracted style overrides (`styles.paragraphStyles` for Heading1/Heading2 etc., matching font/size/color) so the new file reads as the same house style as the template, just regenerated rather than edited in place.
4. Validate with `scripts/office/validate.py`.

## Step 3c: No template (default structure, fresh generation)

Generate via docx-js directly from `references/default-fdd-structure.md`, plain Arial/standard heading styles, no style extraction needed since there's no template to match.
