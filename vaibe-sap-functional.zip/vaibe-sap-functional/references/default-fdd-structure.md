# Default FDD Structure (Vaibe house structure)

Used when no template is uploaded, or as a fallback for any standard FDD topic the client's own template doesn't already cover in style-match mode. Plain professional Word formatting (Arial, standard heading styles) — no Vaibe branding inside the file.

Skip a section only if it's genuinely not applicable to the requirement type (e.g. "Interface Specification Details" on a pure reporting requirement) — don't pad the document with empty sections.

## 1. Document Control
Table: Document Title | Project / Client | Author | Business Owner | Version | Status (Draft/In Review/Approved) | Date.

## 2. Revision History
Table: Version | Date | Author | Description of Change. Seed row 1 with the current draft.

## 3. Purpose & Business Background
Why this requirement exists — the business problem or opportunity. Pull from the "Business background / problem statement" elicitation field.

## 4. Scope
**In Scope** / **Out of Scope** as two clearly separated bullet lists. If the user didn't explicitly state out-of-scope items, mark this subsection `<TBD — confirm with business>` rather than guessing boundaries.

## 5. As-Is Process
Current state. If requirement type = New process, state plainly "No existing process — net new functionality" instead of leaving the heading empty.

## 6. To-Be Process / Functional Requirement Description
The core deliverable. Numbered step-by-step description of the desired functionality, written at business-process level (who does what, triggered by what, expected system behavior) — not ABAP/technical syntax. This is the longest and most important section; expand on the elicited "To-Be" field, organizing it into clear sub-steps if the input was a single block of text.

## 7. Process Flow
A simple numbered or bulleted sequence of process steps (textual flow, not a technical sequence diagram) — trigger → step → step → outcome. Offer to add a `visualize:show_widget` (`diagram` module) flowchart inline in the chat response alongside the doc if the process has more than ~4 steps and the user would benefit from seeing it, but the .docx body stays text-based unless the user asks for an embedded diagram image.

## 8. Detailed Functional Requirements
Break out by sub-topic relevant to the requirement type:
- **Master Data Impact** — fields/objects affected.
- **Configuration Impact** — config areas touched (named generically, e.g. "pricing procedure", not IMG node paths, unless the user supplied them).
- **Business Rules / Validation Logic** — conditions, edge cases, exception handling described in business terms.

## 9. Suggested Technical Approach (For Technical Team to Validate)
Advisory recommendations only — opens the technical conversation, doesn't close it. Every entry is a suggestion, not a commitment, and is written for a functional reader: lead with the business reason, put the object name in parentheses second.

Table: Functional Need | Recommended Approach (Standard / Custom) | Suggested Object(s) | Why This Approach | Status.
- **Functional Need** — the specific to-be step this addresses, not the whole requirement.
- **Recommended Approach** — Standard or Custom, the call a functional reader actually cares about.
- **Suggested Object(s)** — the table/CDS view/FM/BAPI/OData service name(s), as a reference.
- **Why This Approach** — one plain-language sentence. E.g. "Standard posting logic already handles batch/serial validation and stays upgrade-safe" — not "calls BAPI_GOODSMVT_CREATE with parameter X."
- **Status** — always `To be confirmed by technical team` for a suggested entry; only changes if the user explicitly confirmed an object themselves.

If no clean standard object exists for a need, write that plainly in the Why column ("no single standard object covers this — technical team will need to assess") instead of naming something shaky to fill the row. If the user already named specific objects, list those with Status `Provided by business/functional team` instead of the advisory flag.

Skip this section entirely if the elicitation toggle for it was answered "No."

## 10. Data Requirements
Table: Field/Data Element | Source | Description | Mandatory (Y/N). Pull from "Key data elements / fields impacted".

## 11. Integration / Interface Requirements
Only if requirement type = Interface, or touchpoints were given. Table: System | Direction (In/Out) | Trigger | Frequency | Data Exchanged.

## 12. Reporting / Output Requirements
Only if requirement type = Reporting, or output requirements were given. Layout description, selection criteria, frequency, distribution.

## 13. Authorization & Security
Roles/restrictions impacted. Default to "Standard authorization applies — no new restriction" if the user left this blank, rather than `<TBD>`, since "nothing special" is itself a meaningful default for this particular field (unlike business-critical fields where guessing is unsafe).

## 14. Assumptions & Constraints
Bullet list from elicitation field.

## 15. Dependencies
Other projects, requirements, or system changes this depends on. `<TBD — confirm with business>` if not stated and the requirement type suggests dependencies are likely (Interface, Enhancement).

## 16. Testing & Acceptance Criteria
What "done" looks like from the business side — expected outcomes per scenario, not technical unit-test cases (that's `vaibe-sap-developer`'s territory).

## 17. Open Issues / Risks
Table: Issue/Risk | Owner | Status.

## 18. Sign-Off
Table: Name | Role | Signature | Date — rows for Business Owner, IT/Functional Lead, and any named approvers from Document Control.
